.. SIPp documentation master file, created by
   sphinx-quickstart on Tue Dec 27 16:20:26 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Create your own XML scenarios
=============================

.. toctree::
   :maxdepth: 5
   :caption: Contents:

   ownscenarios
   keywords
   actions
   variables
   inject_from_csv
   cond_branching
   sipauth
   init_stanza